package scriddle.dooble;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.app.Activity;
//import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.view.ViewGroup;

import android.support.v4.app.Fragment;

public class HostBeginFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.host_begin_fragment,
                container, false);

        return view;
    }
}
