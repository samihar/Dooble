package scriddle.dooble;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.util.Log;
import android.view.WindowManager;
import android.os.Build;
import android.widget.AdapterView;

import android.widget.Button;
import android.widget.EditText;

import android.app.ProgressDialog;

import java.nio.charset.Charset;
import android.widget.ProgressBar;

import android.Manifest;

import android.widget.ListView;

//import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.lang.Boolean;
import android.app.FragmentManager;



import java.io.IOException;
import java.util.UUID;
import java.util.ArrayList;
//import android.app.Fragment;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothDevice;

public class BeginGame extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private static final int REQUEST_BEGIN_DISCOVERY = 1;
    private static final UUID mUUID  = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");
    private static final UUID m2UUID = UUID.fromString("fdd51efb-0a10-4d27-bd82-1ef5451d8b8a");

    private static final String TAG = "ConnectPhones";
    BluetoothAdapter mBluetoothAdapter;

    public ArrayList<BluetoothDevice> mBTDevices = new ArrayList<>();

    public DeviceListAdapter mDeviceListAdapter;


    ListView lvNewDevices;
    BluetoothDevice mBTDevice;
    GameConnection mGameConnection;
    public ArrayList <GameConnection> Players;

    Button btnSend;
    EditText etSend;

    StringBuilder messages;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_begin_game);
        // open intitial fragment
        /*
        HostBeginFragment fr = new HostBeginFragment();
        android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.host_begin_fragment, fr);
        fragmentTransaction.commit();
*/

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        lvNewDevices = (ListView) findViewById(R.id.lvNewDevices);
        mBTDevices = new ArrayList<>();
        Players = new ArrayList<>();
        lvNewDevices.setOnItemClickListener(BeginGame.this);

        enableDiscoverable();
        Log.d(TAG, "found the end");

        btnSend = (Button) findViewById(R.id.btnSend);
        etSend = (EditText) findViewById(R.id.editText);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                byte[] bytes = etSend.getText().toString().getBytes(Charset.defaultCharset());
                Players.get(0).write(bytes);
                Players.get(1).write(bytes);
                etSend.setText("");
            }
        });

    }


    // enable Bluetooth Discoverability
    public void enableDiscoverable() {
        Log.d(TAG, "Device will be discoverable for 300 seconds");
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivityForResult(discoverableIntent, REQUEST_BEGIN_DISCOVERY);

        IntentFilter DiscoveryIntentFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(discoverableBroadcastReceiver, DiscoveryIntentFilter);
    }


    // BroadcastReceiver for discovering.
    private final BroadcastReceiver discoverableBroadcastReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(mBluetoothAdapter.ACTION_SCAN_MODE_CHANGED)) {
                final int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, mBluetoothAdapter.ERROR);

                // 4 states: turning on, on, turning off, off
                switch(mode){
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(TAG, "Device is connectable and discoverable");
                        break;
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(TAG, "Device is disconnected but able to receive connections");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(TAG, "Device is connecting");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(TAG, "Device is connected");
                        break;
                }
            }
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode) {
            case REQUEST_BEGIN_DISCOVERY:
                Log.d(TAG, "dare i hope");
                discover();
                break;
        }
    }

    public void discover()
    {

        if(mBluetoothAdapter.isDiscovering()){
            mBluetoothAdapter.cancelDiscovery();
            Log.d(TAG, "btnDiscover: Canceling discovery.");

            //check BT permissions in manifest
            checkBTPermissions();

            mBluetoothAdapter.startDiscovery();
            IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
        }
        else {

            //check BT permissions in manifest
            checkBTPermissions();

            mBluetoothAdapter.startDiscovery();
            IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
        }
    }

    /**
     * This method is required for all devices running API23+
     * Android must programmatically check the permissions for bluetooth. Putting the proper permissions
     * in the manifest is not enough.
     *
     * NOTE: This will only execute on versions > LOLLIPOP because it is not needed otherwise.
     */
    private void checkBTPermissions() {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            int permissionCheck =  checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck +=  checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != 0) {

                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1001); //Any number
            }
        }else{
            Log.d(TAG, "checkBTPermissions: No need to check permissions. SDK version < LOLLIPOP.");
        }
    }


    /**
     * Broadcast Receiver for listing devices that are not yet paired
     * -Executed by btnDiscover() method.
     */
    private BroadcastReceiver mBroadcastReceiver3 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "onReceive: ACTION FOUND.");

            if (action.equals(BluetoothDevice.ACTION_FOUND)){
                BluetoothDevice device = intent.getParcelableExtra (BluetoothDevice.EXTRA_DEVICE);
                mBTDevices.add(device);
                Log.d(TAG, "onReceive: " + device.getName() + ": " + device.getAddress());
                mDeviceListAdapter = new DeviceListAdapter(context, R.layout.device_adapter_view, mBTDevices);
                lvNewDevices.setAdapter(mDeviceListAdapter);
            }
        }
    };

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        //first cancel discovery because its very memory intensive.
        //mBluetoothAdapter.cancelDiscovery();

        Log.d(TAG, "onItemClick: You Clicked on a device.");
        String deviceName = mBTDevices.get(i).getName();
        String deviceAddress = mBTDevices.get(i).getAddress();

        Log.d(TAG, "onItemClick: deviceName = " + deviceName);
        Log.d(TAG, "onItemClick: deviceAddress = " + deviceAddress);

        //create the bond.
        //NOTE: Requires API 17+? I think this is JellyBean
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN_MR2){



            Log.d(TAG, "Trying to pair with " + deviceName);
            mBTDevices.get(i).createBond();

            //added progress bar to block screen while waiting for connection
            //ProgressBar pb = (ProgressBar) findViewById(R.id.pbLoading);
            //pb.setVisibility(ProgressBar.VISIBLE);
            //getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            //        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

            mBTDevice = mBTDevices.get(i);
            if (Players.size() < 1)
                mGameConnection = new GameConnection.Builder()
                        .setUUID(mUUID)
                        .setContext(BeginGame.this)
                        .create();
            else
                mGameConnection = new GameConnection.Builder()
                        .setUUID(m2UUID)
                        .setContext(BeginGame.this)
                        .create();
            Log.d(TAG, "Added a connection");
            Players.add(mGameConnection);
            //pb.setVisibility(ProgressBar.INVISIBLE);
            //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }
    }

    public void btnReady(View view) {
        //Players.get(0).write();
        //Players.get(0).write();
    }
}

