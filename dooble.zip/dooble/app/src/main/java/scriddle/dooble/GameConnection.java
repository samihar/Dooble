package scriddle.dooble;

import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.util.Log;


import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import java.io.InputStream;
import java.io.OutputStream;
import android.app.ProgressDialog;
import java.nio.charset.Charset;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothDevice;

import android.support.v4.content.LocalBroadcastManager;

public class GameConnection {

    private static final String TAG = "GameConnection";
    private static UUID mUUID;//  = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");
    //private static final UUID m2UUID = UUID.fromString("88d30118-60d2-4bc2-a54f-238b1a369fc8");

    //private static final UUID m1UUID  = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");
    //private static final UUID m2UUID = UUID.fromString("fdd51efb-0a10-4d27-bd82-1ef5451d8b8a");

    private static final String appName = "dooble";

    public boolean success;

    Context mContext;
    ProgressDialog mProgressDialog;
    private UUID deviceUUID;

    private BluetoothDevice mDevice;
    private BluetoothAdapter mBluetoothAdapter;

    private AcceptThread mInsecureAcceptThread;
    private ConnectThread mConnectThread;
    private ConnectedThread mConnectedThread;

    /*
    private ArrayList<String> mDeviceAddresses;
    private ArrayList<ConnectedThread> mThreads;
    private ArrayList<BluetoothSocket> mSockets;
    private ArrayList<UUID> mUUIDs;
    */

    static class Builder {
        private UUID mmUUID;
        private Context mmContext;

        public Builder setUUID(final UUID bUUID) {
            this.mmUUID = bUUID;
            return this;
        }
        public Builder setContext(final Context bContext) {
            this.mmContext = bContext;
            return this;
        }

        public GameConnection create() {
            return new GameConnection(this);
        }
    }

    private GameConnection(final Builder builder) {
        mUUID = builder.mmUUID;
        mContext = builder.mmContext;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        success = false;
        start();
    }

    /*
    public GameConnection(Context context) {
        mContext = context;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        //mUUID = inUUID;

        /*
        mDeviceAddresses = new ArrayList<String>();
        mThreads = new ArrayList<ConnectedThread>();
        mSockets = new ArrayList<BluetoothSocket>();
        mUUIDs = new ArrayList<UUID>();

        mUUIDs.add(UUID.fromString("b7746a40-c758-4868-aa19-7ac6b3475dfc"));
        mUUIDs.add(UUID.fromString("2d64189d-5a2c-4511-a074-77f199fd0834"));
        mUUIDs.add(UUID.fromString("e442e09a-51f3-4a7b-91cb-f638491d1412"));

        start();
    }
*/
    // Thread will run while listening for incoming connections
    // Runs until a connection is accepted/cancelled
    private class AcceptThread extends Thread {

        // The local server socket
        private final BluetoothServerSocket mmServerSocket;

        public AcceptThread(){
            BluetoothServerSocket tmp = null;

            // Create a new listening server socket
            try{
                tmp = mBluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(appName, mUUID);
                Log.d(TAG, "AcceptThread: Setting up Server using: " + mUUID);
            }catch (IOException e){
                Log.e(TAG, "AcceptThread: IOException: " + e.getMessage() );
            }

            mmServerSocket = tmp;
        }

        public void run(){
            Log.d(TAG, "run: AcceptThread Running.");

            BluetoothSocket socket = null;

            try{
                // This is a blocking call and will only return on a
                // successful connection or an exception
                Log.d(TAG, "run: RFCOM server socket start.....");

                socket = mmServerSocket.accept();
                success = true;

                Log.d(TAG, "run: RFCOM server socket accepted connection.");

            }catch (IOException e){
                Log.e(TAG, "AcceptThread: IOException: " + e.getMessage() );
            }

            //talk about this is in the 3rd
            if(socket != null){
                connected(socket,mDevice);
            }

            Log.i(TAG, "END mAcceptThread ");
        }

        public void cancel() {
            Log.d(TAG, "cancel: Canceling AcceptThread.");
            try {
                mmServerSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "cancel: Close of AcceptThread ServerSocket failed. " + e.getMessage() );
            }
        }

    }


    // Runs while attempting to make an outgoing connection with a device
    // Runs straight through, connection either succeeds or fails
    private class ConnectThread extends Thread {
        private BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device, UUID uuid) {
            Log.d(TAG, "ConnectThread: started.");
            mDevice = device;
            deviceUUID = uuid;
        }

        public void run(){
            BluetoothSocket tmp = null;
            Log.i(TAG, "RUN mConnectThread ");

            // Get a BluetoothSocket for a connection with the
            // given BluetoothDevice
            try {
                Log.d(TAG, "ConnectThread: Trying to create InsecureRfcommSocket using UUID: "
                        + mUUID );
                tmp = mDevice.createRfcommSocketToServiceRecord(mUUID);
            } catch (IOException e) {
                Log.e(TAG, "ConnectThread: Could not create InsecureRfcommSocket " + e.getMessage());
            }

            mmSocket = tmp;

            // Always cancel discovery because it will slow down a connection
            mBluetoothAdapter.cancelDiscovery();

            // Make a connection to the BluetoothSocket

            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
                mmSocket.connect();
                success = true;

                Log.d(TAG, "run: ConnectThread connected.");
            } catch (IOException e) {
                // Close the socket
                try {
                    mmSocket.close();
                    Log.d(TAG, "run: Closed Socket.");
                } catch (IOException e1) {
                    Log.e(TAG, "mConnectThread: run: Unable to close connection in socket " + e1.getMessage());
                }
                Log.d(TAG, "run: ConnectThread: Could not connect to UUID: " + mUUID );
            }

            //will talk about this in the 3rd video
            connected(mmSocket,mDevice);
        }
        public void cancel() {
            try {
                Log.d(TAG, "cancel: Closing Client Socket.");
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "cancel: close() of mmSocket in Connectthread failed. " + e.getMessage());
            }
        }
    }


    // Starts the connections service
    // Start AcceptThread to begin listening in server mode
    public synchronized void start() {
        Log.d(TAG, "start");

        // Cancel any thread attempting to make a connection
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }
        if (mInsecureAcceptThread == null) {
            mInsecureAcceptThread = new AcceptThread();
            mInsecureAcceptThread.start();
        }
    }

    // AcceptThread starts and sit waiting for a connection
    // Then ConnectThread starts & attempts to make a connection w/other diveces AcceptThread
    public void startClient(BluetoothDevice device,UUID uuid){
        Log.d(TAG, "startClient: Started.");

        //initprogress dialog
        mProgressDialog = ProgressDialog.show(mContext,"Connecting Bluetooth"
                ,"Please Wait...",true);

        mConnectThread = new ConnectThread(device, mUUID);
        mConnectThread.start();
    }

    // Connected Thread Class
    // Responsible for mainting BT Conncetion, sending data, & recieving data
    // throough inout output streams
    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            Log.d(TAG, "ConnectedThread: Starting.");

            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            //dismiss the progressdialog when connection is established
            try{
                mProgressDialog.dismiss();
            }catch (NullPointerException e){
                e.printStackTrace();
            }


            try {
                tmpIn = mmSocket.getInputStream();
                tmpOut = mmSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run(){
            byte[] buffer = new byte[1024];  // buffer store for the stream

            int bytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs
            while (true) {
                // Read from the InputStream
                try {
                    bytes = mmInStream.read(buffer);
                    String incomingMessage = new String(buffer, 0, bytes);
                    Log.d(TAG, "InputStream: " + incomingMessage);

                    Intent incomingMessageIntent = new Intent("incomingMessage");
                    incomingMessageIntent.putExtra("theMessage", incomingMessage);
                    LocalBroadcastManager.getInstance(mContext).sendBroadcast(incomingMessageIntent);

                } catch (IOException e) {
                    Log.e(TAG, "write: Error reading Input Stream. " + e.getMessage() );
                    break;
                }
            }
        }

        //Call this from the main activity to send data to the remote device
        public void write(byte[] bytes) {
            String text = new String(bytes, Charset.defaultCharset());
            Log.d(TAG, "write: Writing to outputstream: " + text);
            try {
                mmOutStream.write(bytes);
            } catch (IOException e) {
                Log.e(TAG, "write: Error writing to output stream. " + e.getMessage() );
            }
        }

        /* Call this from the main activity to shutdown the connection */
        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }

    private synchronized void connected(BluetoothSocket mmSocket, BluetoothDevice mmDevice) {
        Log.d(TAG, "connected: Starting.");

        // Start the thread to manage the connection and perform transmissions
        mConnectedThread = new ConnectedThread(mmSocket);
        mConnectedThread.start();
    }


    // write to the connectedThread in an unsycnrhocnized manner
    // out - bytes to write (ConnectedThread write(byte[]))
    public void write(byte[] out) {
        /*
        for (int i = 0; i <mThreads.size(); i++) {
            try {
                // Create temporary object
                ConnectedThread r;

                // Synchronize a copy of the ConnectedThread
                synchronized (this) {
                    r = mThreads.get(i);
                }

                r.write(out);


            } catch (Exception e) {

            }
        }*/

        // Create temporary object
        ConnectedThread r; // lmao what is this for

        // Synchronize a copy of the ConnectedThread
        Log.d(TAG, "write: Write Called.");
        //perform the write
        mConnectedThread.write(out);
    }


}



